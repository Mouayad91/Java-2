/**
 * Abstakte-Klasse zum deklarieren von abstrakte Methoden.
 * 
 * @author Monzr Hajy Omar und Mouayad Haji Omar
 * 
 * @version 1.0
 */
public abstract class Palindorm_Iterative_Rekursive implements Palindrom{

  private int gewählte_type;
  
  public Palindorm_Iterative_Rekursive(int gewählte_type) {
    this.gewählte_type = gewählte_type;
  }

}
