/**
 * Interface-Klasse zum erbung der Methode und Konstanten.
 * 
 * @author Monzr Hajy Omar und Mouayad Haji Omar
 * 
 * @version 1.0
 */
public interface Palindrom {

  public boolean istPalindrom(String wort);

}
